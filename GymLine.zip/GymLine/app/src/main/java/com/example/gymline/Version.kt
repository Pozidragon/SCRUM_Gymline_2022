package com.example.gymline

data class Version(
    var version: Double? = null){
}